# Intent Compiler experiment package

> **Development entry (2026-10-02):** Read [CONTEXT.md](CONTEXT.md) for terminology, [CURRENT-DESIGN.md](development/CURRENT-DESIGN.md) §13.31–13.33 for the current removals, completed R1–R5 run and bounded source-selection evidence, and the [committed evidence record](experiments/evocode/harbor/dpipe/records/2026-10-02-source-selection/REPORT.txt). The implementation tested in that run is c6e1f64. This update records evidence only; source-interface changes and another model run are not authorized.

The IR continuously maintains the overall task intent. Its Compiled Intent is the overall execution plan containing Atoms, Relations and IR references. Each Atom must state executable behavior and completion evidence; references and coverage cannot substitute for that content.

A historical full dpipe first-round management smoke produced one IR containing 9 content items, and one Compiled Intent containing 5 Atoms and 4 Relations, with only the first Atom dispatchable. That Atom omitted exact rejection strings and added an unsupported lowercase checksum restriction. The Compiled Intent therefore failed semantic fidelity; the entire IR has not yet been semantically validated either. This run had one proposal, no independent check, no business execution and no verifier result. Source preservation and correct delivery do not establish semantic correctness.

The current work is semantic analysis and compilation. The following first-candidate overview and module descriptions explain earlier implementation only; use the current design and source for V2 behavior.


This package contains the deterministic first-candidate code for development modules 02–05, the TypeScript Observer from module 06, and the adapter/runtime code from modules 07–09. The candidate covers state changes and Compiled Intent projection, independent Compiler storage, a restricted model-change proposal, and a single host-facing Compiler interface. These source modules and their local deterministic checks do not prove model understanding or execution value.

The OpenCode adapter, prdcheck boundary conversion, independent OpenCode model transport, and environment-backed runtime construction exist as source code with local deterministic tests. One no-tools compatibility run has completed through OpenCode, Luna, deterministic validation, Compiled Intent delivery, executor response, and terminal reconciliation. The prdcheck host wiring and a real coding task remain incomplete, so no execution-value or experiment result is claimed.

In `compat-007`, Luna proposed `no_change`, leaving state version 0 with no selected task or requirements. The harness itself requested `COMPATIBILITY_OK`; the executor response therefore does not establish semantic success. Exact evidence and the authorized first-request no-tool test are recorded in [development module 09](../reference/history/09-real-chain-smoke/README.md) and the authoritative spec.

The first-request no-tool test was attempted on 2026-09-18. `semantic-001` was rejected for proposal-local references resembling persistent IDs. `semantic-002`, with max effort loaded in the Compiler's resolved model options, committed one task and seven requirements but omitted task selection; Compiled Intent contained no current task or active requirements, and the executor reported that absence. That pre-fix attempt failed. Provider-wire effort was not independently captured; no coding or prdcheck execution occurred.

After clarifying the model-visible contract and rejecting newly created active tasks without any selection at the public turn boundary, `semantic-003` passed the same first-request check: the selected task and all seven requirements reached Compiled Intent and were accurately restated. The two earlier attempts remain failed records. This establishes one-case correctness only. Current work evaluates Compiler products and behavior without requiring a complete coding artifact; broader multi-turn behavior and added value remain unproven.

The subsequent four-turn coding-topic diagnostic `single-coding-001` used the original SWE-bench issue `astropy__astropy-13236` and three locally authored updates. State records superseded the deferral when the user reversed it, and all four deliveries matched their artifacts, but executor restatements on turns 3 and 4 still deferred the restored requirement. This is not a complete semantic pass; the cause remains unresolved. No coding implementation or official Evolving Intent trajectory was executed. See the [diagnostic report](../reference/reports/intent-single-coding-001.md) and [test notes](experiments/intent/README.md).

The subsequent repair clarified preservation of revised scope and optional conditions in the model contract. `single-coding-fix-002` passed manual checks of the same four-turn development case, including the original deferral reversal, and a real-model replay from the original prior state also avoided the deferral. See the [repair report](../reference/reports/intent-single-coding-fix-002.md). This is not deterministic semantic validation or held-out reliability evidence; the first repair attempt omitted an optional condition and remains a failed regression record.

## First-candidate package interface (historical)

The package entry point keeps the host-facing Compiler surface small:

- `createIntentCompiler` and its request/result types for preparing turns, recording delivery, admitting evidence, and recovery;
- the existing Observer plugin, runtime, registry, event store, and report projection exports;
- one OpenCode Adapter factory and one prdcheck Adapter factory;
- one function each for creating a RUN_DIR-local plugin config, recording a turn's JSONL without overwrite, reading the current committed public Compiled Intent, admitting explicitly sourced prdcheck evidence for a named next input, and checking real-run prerequisites without creating a model session.

Compiler store step methods and model transport details are not re-exported as host-facing package entry points. Each host helper has one function name and one parameter shape; there are no compatibility aliases.

The observer is inactive unless an OpenCode session is registered. For registered sessions it:

- records the user-message parts visible at this observer's position in the OpenCode plugin chain without changing them;
- compares matching text-part update events with those observed parts, and later saves an SDK session-messages readback for reconciliation;
- records model requests and persisted token, cost, and timing data;
- records tool starts, completions, failures, permission events, retries, and workspace diffs;
- stores an append-only event log and content-addressed artifacts;
- derives a JSON summary and a simple HTML timeline.

These behaviours make later experiments auditable. They are not evidence that the model understands intent or that the candidate improves execution.

## First-candidate modules (historical)

The first-candidate code was split by responsibility:

- module 02 validates closed proposals, applies all-or-nothing state changes, and projects a canonical Compiled Intent;
- module 03 persists Compiler history, commits, artifacts, delivery attempts, evidence decisions, replay, and recovery separately from Observer storage;
- module 04 constructs a read-only, no-tools model request and parses only the ordered proposal envelope through an injected transport;
- module 05 fixes the host-facing turn order, retry boundary, delivery/evidence boundary, and recovery seam.

The default runtime constructs an independent OpenCode model transport from explicit environment configuration. Real Luna sessions were exercised in `compat-007` and the `semantic-001` through `semantic-003` attempts described above; their compatibility and single-request correctness results do not establish broader multi-turn behavior or added value.

## Source layout

Optional model-comparison tooling lives in [experiments/typesafe](experiments/typesafe/README.md).
It reuses the official Python adapter through an OpenCode provider and has separate
dependencies/audit records; it does not replace the TypeScript Compiler. A real Luna
compatibility check passed, not an Intent correctness comparison. Benchmark preparation
and the missing generated Evolving Intent pool are documented in
[experiments/intent](experiments/intent/README.md).

```text
src/
  core/       deterministic state, storage, projection, and turn ordering
  model/      restricted model request/response and OpenCode transport
  observer/   observation, persistence, reconciliation, and reports
  adapters/   OpenCode and prdcheck boundary conversion
  runtime/    environment-backed OpenCode Compiler construction
  cli/        command-line entry points built into dist/cli
  index.ts    deliberately small package entry point
```

`development/` contains module-specific development instructions and completion records. It is not a second source tree.

## Store

Set `EXPERIMENT_OBSERVER_STORE` to an absolute directory outside the executor workspace. The observer writes:

```text
runs/<run_id>/
  manifest.json
  events.jsonl
  status.json
  summary.json
  report.html
  artifacts/sha256/*
registrations/<session_id>.json
```

The event log and saved artifacts are authoritative. Status, summary, and HTML are derived views.

## Register a session

Create the OpenCode session, then register it before sending the first prompt:

```powershell
npm run build
node ./dist/cli/observer-cli.js register `
  --store C:\absolute\observer-store `
  --run observation-001 --arm raw --task task-001 --turn 1 --session SESSION_ID
```

For a first message whose session ID is not known in advance, set `EXPERIMENT_OBSERVER_AUTO_REGISTER=1` plus `EXPERIMENT_RUN_ID`, `EXPERIMENT_ARM_ID`, `EXPERIMENT_TASK_ID`, and `EXPERIMENT_TURN_ID`. A Compiler run also supplies `EXPERIMENT_INPUT_IDENTITY`, `EXPERIMENT_USER_INPUT_FILE`, `EXPERIMENT_HARNESS_SYSTEM_FILE`, and `EXPERIMENT_EXECUTOR_WORKSPACE`; the two UTF-8 text files must be outside the executor workspace. A host that has them should also supply `EXPERIMENT_INPUT_SOURCE_CATEGORY`, `EXPERIMENT_STAGE_ID`, `EXPERIMENT_PATH_ID`, `EXPERIMENT_ROUND`, `EXPERIMENT_TASK_OCCURRENCE_ID`, `EXPERIMENT_WORKSPACE_SNAPSHOT_ID`, and `EXPERIMENT_INPUT_PRODUCED_AT`. These values are saved as source information; they do not independently change intent. After a session ID is known, later user updates should be explicitly registered before continuing that session.

## Checks

```powershell
npm test
npm run typecheck
```

`npm test` builds the package, compiles the test suite into temporary `.test-dist/`, runs it, and removes that directory after a successful run. The tests include the deterministic candidate and Observer checks. They do not replace a real OpenCode/model-chain run and make no claim about intent understanding or management.

The local checks are deterministic package checks only: host-command and evidence-admission coverage uses local files, stdin, temporary directories, and an in-process proposal. No real model, provider, OpenCode executor session, or prdcheck shell run is represented by these checks, and this README intentionally does not freeze a total test count.
