# 短跑计划（R1–R3）：配置、预算与追溯（2026-09-30，待授权）

> 目的：让当前组合（carry + v1 请求裁剪 + 88ae646 IR 输出调整）接受一次真实运行检查。
> 这是**运行检查**，不是 88ae646 的归因实验（那需要同构建减去该改动的对照）。
> 不启动；不继续删下一组字段。

## 1. 范围与固定配置

| 项 | 值 | 依据 |
| --- | --- | --- |
| 范围 | R1–R3 | 覆盖初始建立、较大的第 2 轮扩展、第 3 轮扩展/修正；此前阻塞都在此区间 |
| 管理模型 | `openai/gpt-6-luna-fast`（manager variant `high-fast`） | 与已有证据同模型，便于对照 |
| 执行模型 | `openai/gpt-6-luna-fast`（executor variant `high-fast`） | 同上 |
| 每批请求上限 | 8 | 156a7e1 的既有设定（IR+CI+check+一次往返+一次机械修复） |
| 全程请求上限 | **40**（比 3 轮理论上限 27 留余量） | 依据：carry run 实测 mgmt-1 7 次、mgmt-2 1 次、mgmt-3 7 次、mgmt-4 6 次（非预估） |
| 单次 prompt 期限 | 300s + abort 确认（既有默认） | 13.22 的既有实现 |
| 轮级超时/测试 | 官方默认（不改题目、不改 verifier） | 用户既有约定 |

**停止条件**：①每批 8 次用尽；②全程 40 次用尽；③新 IR 输出出现连续 2 次形状拒绝时停下分析（问题 1）；④连续 2 轮零派发时停下分析；⑤R3 完成或任一硬性停止命中。

## 2. 冻结版本与相对已有证据的差异

- 冻结 commit：`88ae646`（含此前的 `6d55d2f` carry、`a211324` v1 请求裁剪、`a1764ad` gap 可见性；`7f10f81/249c09e` 的 `view.ts` 在 dist 中但**未接线**，无运行时作用）。
- 相对 carry run 的冻结构建（156a7e1 + 未提交 carry 改动）新增：
  1. **v1 请求裁剪**：IR 阶段不带计划正文/回传证据，segments=引用∪未编译委托∪本批；CI 阶段不带原始来源历史；
  2. **88ae646**：IR 输出不再要求 `execution_decisions/assessments/checks`，`generation_repair.ir_proposal` 统一为 IR 阶段形状（旧草稿恢复时剔除三字段）。
- prepare.py 会把 `dist/.opencode/node_modules` 复制进 `<run>/intent-compiler-runtime` 并写 `runtime-hashes.json`；以此为准。

## 3. 短跑要回答的四个问题（预注册）

1. 管理模型能否正常完成新的 IR 输出要求（有无新增 schema/形状错误）；
2. IR、CI、核对是否仍卡在相同位置（对照 mgmt-3/4 的失败类型）；
3. 是否真正派发、执行后逐轮用例表现（用例数，不只看全有全无的 reward）；
4. 含重试的总调用、input/output token 与墙钟时间。

## 4. 留痕能力核对（现状）

| 需要的证据 | 现状 | 结论 |
| --- | --- | --- |
| 每次实际阶段请求 | `management_log[].attempts[].request`（含 generation_stage / validation_errors / generation_repair / budget 重写值） | 已具备 |
| system prompt 与 response schema | **不逐次落库**，但由冻结 dist 纯函数决定（`MODEL_SYSTEM_PROMPT` + `generationStageInstruction(stage,assessment)` + `buildGenerationSchema(stage,profile)`），可按 stage/profile 逐字节重建 | 可重建（非直存） |
| 模型原始回答 | `attempts[].text`（限长） | 已具备 |
| 核对依据 | 只存 `prepared_digest` + findings/refs；**核对输入与 prepared 本体不落库** | **缺口** |
| 调用计量 | `management_calls[]`（kind/stage/时长/usage） | 已具备 |
| 流诊断 | `audit/management-stream.jsonl`（心跳 + 4KB 采样，不含完整请求） | 仅诊断 |

**最小补法（需授权后实施，纯记录、不改行为）**：在 check 尝试的 `ManagementAttemptRecord` 上追加 `check_input`（events/source_events/ir/compiled/candidate/prepared）。体量约 50–60KB/次核对；3 轮预计 ~10 次核对 → <1MB。若不补，D4 类归因仍只能"未闭合"。

## 5. 启动清单（授权后执行）

1. `python experiments/evocode/harbor/dpipe/prepare.py --run-id intent-luna-dpipe-short-r1r3-<ts>-<id> --model openai/gpt-6-luna-fast`
2. 改 `intent.json`：`multiround_max_round = 3`；store `budget.max_total_management_requests = 40`（每批仍 8）
3. 写 `provenance/run-scope.json`（范围、冻结差异、四个问题、停止条件）
4. 如获授权，先落第 4 节的记录补法并跑 `npm test`
5. 用 `.scratch/launch-smoke.py` 后台启动；报告口径：逐轮用例数 + 派发数 + 调用/token + 失败族分类

## 6. 明确不做

- 不把本次结果归因给 88ae646（需对照构建）；不宣称 token 节省或完成率改善；
- 不继续输入裁剪（existing_objects.atoms / atom_states / capabilities.operations 留待下一项讨论）；
- 不动 D4、task ref 语义、积压规则、提交边界。
