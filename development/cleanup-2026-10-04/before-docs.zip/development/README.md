# Intent Compiler 开发入口

**当前设计、具体接口、实施顺序和验收要求统一在 [CURRENT-DESIGN.md](CURRENT-DESIGN.md)。** OpenCode 直接交付 Atom；本次语义生成契约及整链路修复已实现并完成离线验证，新真实模型产物尚未验收。最新实现与真实未通过结果见 §13.9，原始反例见 §12.7（2026-09-28），[验证记录](validation/2026-09-28-semantic-plan/RESULTS.md)保留实际通过范围。

开发阅读顺序：

1. [CONTEXT.md](../CONTEXT.md)：既有术语。
2. [CURRENT-DESIGN.md](CURRENT-DESIGN.md)：完整当前开发依据；§12.7 固定当前语义修复范围，第 5 部分保留初始改造顺序，不是从头重做的指令。
3. 需要核对现有状态或正式研究要求时，读 [spec.md](../docs/authority/spec.md) 对应段落和后续日期记录。查研究证据时再读[原研究报告](../docs/authority/research.md)及主文档第 7 部分。

原来的 16 份 2026-09-21 讨论稿已放在包内 reference/history/，保留作历史与来源追溯，不是 16 份并列规格。reference/history/ 下的 01–09 模块说明记录首版实现，不再规定下一候选的实现顺序或模型输出限制。其他旧 .scratch/outputs 不作为项目依据。

后续工作以主文档 §13.9 的已实现但语义未通过状态和 §12.7 的原始反例为基础。发现真实反例就在主文档修订对应要求并保留原因，不再新增平行设计稿；记录实际修改、检查与未覆盖边界，不以代码存在或本地测试通过代替语义正确和对照价值。

源码入口：src/core、src/model、src/adapters、src/runtime、src/observer、src/cli。test 是测试；dist 是构建产物，不手改；experiments 是独立实验工具。legacy-external/sdd-loop-prdcheck 尚未接入，本次文档整理不授权宿主改造或模型运行。

**专题地图（wayfinding）：** [wayfinder-cost-structure/map.md](wayfinder-cost-structure/map.md) 是"管理层结构成本与边界"这一专题的决策地图；票据在同目录 `issues/`。它是规划索引，不是规格；结论落定后并入本文档或 CURRENT-DESIGN。

